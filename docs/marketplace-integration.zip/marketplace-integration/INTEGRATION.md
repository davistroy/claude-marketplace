# Integration Guide — arch-review-plugin into claude-marketplace

## What's Being Added

A new plugin that adds a 9-agent comprehensive architecture review team as a complement to the existing `review-arch` quick audit command. The two commands form a two-tier system:

| Command | Mode | Output | Time | Use case |
|---------|------|--------|------|----------|
| `/review-arch` | Quick, read-only | In-conversation | 5–20 min | PR context, rapid spot-checks, CI flags |
| `/arch-review` | Deep, multi-agent | Files on disk | 30–60 min | Pre-release gates, vendor eval, formal review |

---

## Step 1 — Copy Plugin Files

Copy the `arch-review-plugin/` directory into your repo:

```bash
cp -r arch-review-plugin/ /path/to/claude-marketplace/plugins/
```

Final structure:
```
plugins/
  personal-plugin/        ← unchanged
  bpmn-plugin/            ← unchanged
  arch-review-plugin/     ← new
    .claude-plugin/
      plugin.json
    commands/
      arch-review.md
      arch-review-single.md
      arch-synthesize.md
    agents/
      solutions-architect.md
      data-architect.md
      integration-architect.md
      software-engineer.md
      performance-engineer.md
      qa-architect.md
      security-architect.md
      platform-engineer.md
      risk-compliance.md
```

---

## Step 2 — Update marketplace.json

Open `.claude-plugin/marketplace.json` and add the new plugin entry to the `plugins` array. The entry to add is in `marketplace-entry.json` in this package. It should look like:

```json
{
  "plugins": [
    { ... existing personal-plugin entry ... },
    { ... existing bpmn-plugin entry ... },
    {
      "name": "arch-review-plugin",
      "source": "./plugins/arch-review-plugin",
      "description": "Comprehensive 9-agent architecture review team...",
      "version": "1.0.0",
      "author": { "name": "Troy Davis", "email": "troy@stratfieldconsulting.com" },
      "homepage": "https://github.com/davistroy/claude-marketplace",
      "repository": "https://github.com/davistroy/claude-marketplace",
      "license": "MIT",
      "keywords": ["architecture", "review", "security", "agents", "orchestration"],
      "category": "development"
    }
  ]
}
```

---

## Step 3 — Update review-arch.md Related Commands

In `plugins/personal-plugin/commands/review-arch.md`, find the `## Related Commands` section at the bottom and prepend these two lines before the existing entries:

```markdown
* `/arch-review <path>` — **Full 9-agent comprehensive review** with saved artifacts and executive report. Use for pre-release gates, vendor/acquisition evaluations, or any engagement requiring a defensible documented assessment. Requires `arch-review-plugin`. (~30–60 min)
* `/arch-review-single <agent> <path>` — Run one domain agent from the full team (security-architect, software-engineer, etc.) for targeted deep-dives. Requires `arch-review-plugin`.
```

---

## Step 4 — Bump personal-plugin Version (Optional)

If your `personal-plugin/plugin.json` tracks a version, bump it to reflect the Related Commands update.

---

## Step 5 — Validate and Push

```bash
# Validate from your marketplace root
claude plugin validate .

# Run your existing validation workflow
# (your repo has a validate.yml GitHub Action — this will trigger on push)

git add plugins/arch-review-plugin .claude-plugin/marketplace.json \
  plugins/personal-plugin/commands/review-arch.md
git commit -m "feat: add arch-review-plugin — 9-agent comprehensive architecture review team"
git push
```

---

## Step 6 — Install and Test

```bash
# In any project where you want to use the full review team
/plugin marketplace update
/plugin install arch-review-plugin@troys-plugins

# Test against a target
/arch-review /path/to/some/project
```

---

## Relationship Between the Two Commands

The two-tier design is intentional:

`/review-arch` runs with `allowed-tools: Read, Glob, Grep` — strictly read-only, no subagents, in-conversation output only. It's safe to run anywhere, including CI environments where you don't want disk writes. Fast and lightweight.

`/arch-review` runs with `allowed-tools: Read, Glob, Grep, Bash, Task` — spawns 9 parallel subagents, writes structured artifacts to `<target>/arch-review/`, requires Bash for static analysis tools (semgrep, trivy, etc.). Heavy and comprehensive.

Neither replaces the other. `/review-arch` remains the go-to for ongoing development workflow. `/arch-review` is for formal engagements where you need a documented, defensible report.

---

## Optional: Tool Dependencies

For best results from the security and code quality agents, install these on the review machine:

```bash
pip install semgrep bandit pip-audit safety lizard radon --break-system-packages
brew install cloc trivy
npm install -g eslint
```

Agents degrade gracefully if tools are unavailable — they note it in `.meta.json` and proceed with grep-based analysis.
