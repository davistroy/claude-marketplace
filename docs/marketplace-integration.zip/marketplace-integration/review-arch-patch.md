# Patch for plugins/personal-plugin/commands/review-arch.md
#
# In the "Related Commands" section, replace the existing block with this:
# (Add the two new /arch-review lines — the rest stays identical)

## Related Commands

* `/arch-review <path>` — **Full 9-agent comprehensive review** with saved artifacts and executive report. Use for pre-release gates, vendor/acquisition evaluations, or any engagement requiring a defensible documented assessment. Requires `arch-review-plugin`. (~30–60 min)
* `/arch-review-single <agent> <path>` — Run one domain agent from the full team (security-architect, software-engineer, etc.) for targeted deep-dives. Requires `arch-review-plugin`.
* `/plan-improvements` — Comprehensive analysis that generates RECOMMENDATIONS.md and IMPLEMENTATION_PLAN.md
* `/review-intent` — Compare original intent vs current implementation (complementary review)
* `/review-pr` — Review a specific pull request for code quality and security
* `/plan-next` — Get a recommendation for the next action based on current state
